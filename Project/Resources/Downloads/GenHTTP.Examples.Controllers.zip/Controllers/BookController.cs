﻿using System.Collections.Generic;
using System.Linq;

using GenHTTP.Api.Content;
using GenHTTP.Api.Content.Templating;
using GenHTTP.Api.Protocol;

using GenHTTP.Examples.Controllers.Model;

using GenHTTP.Modules.Basics;
using GenHTTP.Modules.Controllers;
using GenHTTP.Modules.IO;
using GenHTTP.Modules.Scriban;

namespace GenHTTP.Examples.Controllers.Controllers
{

    public class BookController
    {
        private static readonly List<Book> _Books = new List<Book>()
        {
            new Book() { ID = 1, Title = "Lord of The Rings" }
        };

        public IHandlerBuilder Index()
        {
            return ModScriban.Page(Data.FromResource("BookList.html"), (r, h) => new ViewModel(r, h, _Books))
                             .Title("Book List");
        }

        public IHandlerBuilder Create()
        {
            return ModScriban.Page(Data.FromResource("BookCreation.html"))
                             .Title("Add Book");
        }

        [ControllerAction(RequestMethod.POST)]
        public IHandlerBuilder Create(string title)
        {
            var book = new Book()
            {
                ID = _Books.Max(b => b.ID) + 1,
                Title = title
            };

            _Books.Add(book);

            return Redirect.To("{index}/", true);
        }

        public IHandlerBuilder Edit([FromPath] int id)
        {
            var book = _Books.Where(b => b.ID == id).First();

            return ModScriban.Page(Data.FromResource("BookEditor.html"), (r, h) => new ViewModel(r, h, book))
                             .Title(book.Title);
        }

        [ControllerAction(RequestMethod.POST)]
        public IHandlerBuilder Edit([FromPath] int id, string title)
        {
            var book = _Books.Where(b => b.ID == id).First();

            book.Title = title;

            return Redirect.To("{index}/", true);
        }

        [ControllerAction(RequestMethod.POST)]
        public IHandlerBuilder Delete([FromPath] int id)
        {
            _Books.RemoveAll(b => b.ID == id);

            return Redirect.To("{index}/", true);
        }

    }

}
