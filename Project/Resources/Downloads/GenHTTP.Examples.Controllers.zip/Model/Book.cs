﻿namespace GenHTTP.Examples.Controllers.Model
{

    public class Book
    {

        public int ID { get; set; }

        public string Title { get; set; }

    }

}
