﻿using System;

using GenHTTP.Engine;

using GenHTTP.Modules.Layouting;
using GenHTTP.Modules.Practices;
using GenHTTP.Modules.Controllers;

using GenHTTP.Themes.Lorahost;
using GenHTTP.Modules.Core;
using GenHTTP.Modules.Placeholders;
using GenHTTP.Examples.Controllers.Controllers;

namespace GenHTTP.Examples.Controllers
{

    class Program
    {
        static int Main(string[] args)
        {
            var app = Layout.Create()
                            .AddController<BookController>("books")
                            .Index(Page.From("Welcome to the Book Manager!"));

            var theme = Theme.Create()
                             .Title("Book Manager");

            var website = Website.Create()
                                 .Theme(theme)
                                 .Content(app);

            return Host.Create()
                       .Handler(website)
                       .Defaults()
                       .Development()
                       .Console()
                       .Run();
        }

    }

}
