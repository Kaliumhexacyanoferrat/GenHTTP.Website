﻿namespace GenHTTP.Examples.Controllers.Model
{

    public record Book(int ID, string Title);

}
