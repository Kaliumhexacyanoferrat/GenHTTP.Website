﻿using System.Collections.Generic;
using System.Linq;

using GenHTTP.Api.Content;
using GenHTTP.Api.Content.Templating;
using GenHTTP.Api.Protocol;

using GenHTTP.Examples.Controllers.Model;

using GenHTTP.Modules.Basics;
using GenHTTP.Modules.Controllers;
using GenHTTP.Modules.IO;
using GenHTTP.Modules.Scriban;

namespace GenHTTP.Examples.Controllers.Controllers
{

    public class BookController
    {
        private static readonly List<Book> _Books = new()
        {
            new Book(1, "Lord of The Rings")
        };

        public IHandlerBuilder Index()
        {
            return ModScriban.Page(Resource.FromAssembly("BookList.html"), (r, h) => new ViewModel(r, h, _Books))
                             .Title("Book List");
        }

        public IHandlerBuilder Create()
        {
            return ModScriban.Page(Resource.FromAssembly("BookCreation.html"))
                             .Title("Add Book");
        }

        [ControllerAction(RequestMethod.POST)]
        public IHandlerBuilder Create(string title)
        {
            var book = new Book(_Books.Max(b => b.ID) + 1, title);

            _Books.Add(book);

            return Redirect.To("{index}/", true);
        }

        public IHandlerBuilder Edit([FromPath] int id)
        {
            var book = _Books.Where(b => b.ID == id).First();

            return ModScriban.Page(Resource.FromAssembly("BookEditor.html"), (r, h) => new ViewModel(r, h, book))
                             .Title(book.Title);
        }

        [ControllerAction(RequestMethod.POST)]
        public IHandlerBuilder Edit([FromPath] int id, string title)
        {
            var book = _Books.Where(b => b.ID == id).First();

            var index = _Books.IndexOf(book);

            _Books[index] = book with { Title = title };

            return Redirect.To("{index}/", true);
        }

        [ControllerAction(RequestMethod.POST)]
        public IHandlerBuilder Delete([FromPath] int id)
        {
            _Books.RemoveAll(b => b.ID == id);

            return Redirect.To("{index}/", true);
        }

    }

}
